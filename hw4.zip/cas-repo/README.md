# Clinical Appointment System (CAS) - MVP

Repository package prepared from the project brief for the Clinical Appointment System using the revised stack: **Spring Boot + PostgreSQL + React**.

## Included deliverables
- Source code (backend + frontend MVP)
- CI/CD workflow (`.github/workflows/ci.yml`)
- Documentation (`README`, architecture notes, risk updates, demo plan)
- Sprint board reference file
- Docker-based local run setup

## Project board
- Sprint board link placeholder: `https://github.com/<your-username>/<your-repo>/projects`
- Replace it with the real GitHub Projects board after creating the repository.
- See `docs/SPRINT_BOARD.md` for suggested columns and sprint items.

## MVP scope
Aligned to the uploaded project brief:
- Patients can view doctors
- Patients can create appointments
- Patients can cancel appointments
- Admin/doctor visibility of appointment list
- PostgreSQL persistence with Flyway migration

## Architecture
- Frontend: React + Vite
- Backend: Java 17 + Spring Boot
- Database: PostgreSQL
- CI/CD: GitHub Actions
- Containerization: Docker Compose

## Quick start
### 1. Run with Docker Compose
```bash
docker compose up --build
```

### 2. Local URLs
- Frontend: `http://localhost:5173`
- Backend: `http://localhost:8080`
- Health check: `http://localhost:8080/api/health`

## API
### GET `/api/health`
Returns service status.

### GET `/api/doctors`
Returns active doctors.

### GET `/api/appointments`
Returns appointments sorted by time.

### POST `/api/appointments`
Example body:
```json
{
  "doctorId": 1,
  "patientName": "Ali Veli",
  "appointmentTime": "2026-04-10T10:00:00"
}
```

### PATCH `/api/appointments/{id}/cancel`
Cancels an appointment.

## Suggested GitHub repository structure
```text
.
├── .github/workflows/ci.yml
├── backend/
├── frontend/
├── docs/
├── docker-compose.yml
└── README.md
```

## CI/CD notes
Current CI verifies:
- Backend tests pass
- Frontend builds successfully

Suggested CD extension after repo creation:
- Push to `main`
- Build Docker images
- Deploy backend to Render/Railway/Fly.io or VM
- Deploy frontend to Vercel/Netlify

## Demo checklist
See `docs/DEMO_PLAN.md`.

## Risk management
See `docs/RISK_UPDATES.md`.

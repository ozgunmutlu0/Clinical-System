package com.example.cas.entity;

public enum AppointmentStatus {
    BOOKED,
    COMPLETED,
    CANCELED,
    NO_SHOW
}

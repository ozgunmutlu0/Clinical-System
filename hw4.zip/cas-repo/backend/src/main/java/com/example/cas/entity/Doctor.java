package com.example.cas.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "doctors")
public class Doctor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false)
    private String fullName;

    @NotBlank
    @Column(nullable = false)
    private String specialty;

    @Column(nullable = false)
    private boolean active = true;

    public Doctor() {}

    public Doctor(String fullName, String specialty, boolean active) {
        this.fullName = fullName;
        this.specialty = specialty;
        this.active = active;
    }

    public Long getId() { return id; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getSpecialty() { return specialty; }
    public void setSpecialty(String specialty) { this.specialty = specialty; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}

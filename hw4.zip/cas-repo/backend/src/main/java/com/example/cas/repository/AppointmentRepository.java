package com.example.cas.repository;

import com.example.cas.entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    List<Appointment> findByDoctorIdOrderByAppointmentTimeAsc(Long doctorId);
    List<Appointment> findAllByOrderByAppointmentTimeAsc();
    Optional<Appointment> findByAppointmentTime(LocalDateTime appointmentTime);
}

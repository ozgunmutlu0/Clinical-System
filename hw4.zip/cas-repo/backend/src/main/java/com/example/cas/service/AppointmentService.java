package com.example.cas.service;

import com.example.cas.dto.CreateAppointmentRequest;
import com.example.cas.entity.Appointment;
import com.example.cas.entity.AppointmentStatus;
import com.example.cas.entity.Doctor;
import com.example.cas.repository.AppointmentRepository;
import com.example.cas.repository.DoctorRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class AppointmentService {
    private final AppointmentRepository appointmentRepository;
    private final DoctorRepository doctorRepository;

    public AppointmentService(AppointmentRepository appointmentRepository, DoctorRepository doctorRepository) {
        this.appointmentRepository = appointmentRepository;
        this.doctorRepository = doctorRepository;
    }

    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAllByOrderByAppointmentTimeAsc();
    }

    public Appointment createAppointment(CreateAppointmentRequest request) {
        Doctor doctor = doctorRepository.findById(request.getDoctorId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Doctor not found"));

        if (appointmentRepository.findByAppointmentTime(request.getAppointmentTime()).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Time slot already booked");
        }

        Appointment appointment = new Appointment(
                doctor,
                request.getPatientName(),
                request.getAppointmentTime(),
                AppointmentStatus.BOOKED
        );

        return appointmentRepository.save(appointment);
    }

    public Appointment cancelAppointment(Long id) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Appointment not found"));
        appointment.setStatus(AppointmentStatus.CANCELED);
        return appointmentRepository.save(appointment);
    }
}

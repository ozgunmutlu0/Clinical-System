package com.example.cas.service;

import com.example.cas.entity.Doctor;
import com.example.cas.repository.DoctorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService {
    private final DoctorRepository doctorRepository;

    public DoctorService(DoctorRepository doctorRepository) {
        this.doctorRepository = doctorRepository;
    }

    public List<Doctor> getActiveDoctors() {
        return doctorRepository.findByActiveTrue();
    }
}

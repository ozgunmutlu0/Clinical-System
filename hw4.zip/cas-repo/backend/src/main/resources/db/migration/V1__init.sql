CREATE TABLE doctors (
    id BIGSERIAL PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    specialty VARCHAR(255) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE appointments (
    id BIGSERIAL PRIMARY KEY,
    doctor_id BIGINT NOT NULL REFERENCES doctors(id),
    patient_name VARCHAR(255) NOT NULL,
    appointment_time TIMESTAMP NOT NULL UNIQUE,
    status VARCHAR(50) NOT NULL
);

INSERT INTO doctors (full_name, specialty, active) VALUES
('Dr. Ayse Demir', 'Cardiology', TRUE),
('Dr. Mehmet Kaya', 'Dermatology', TRUE),
('Dr. Elif Arslan', 'Pediatrics', TRUE);

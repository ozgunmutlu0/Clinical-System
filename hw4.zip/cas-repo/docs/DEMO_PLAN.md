# Live Demo Plan

## Goal
Show a working MVP, repository structure, CI pipeline, and project board in one short flow.

## Demo sequence
1. Open GitHub repository root
2. Show `README.md` and folder structure
3. Open GitHub Actions and show green CI run
4. Open Project board and show sprint cards/status
5. Start the app locally with Docker Compose
6. Open frontend dashboard
7. Show doctor list
8. Create or show an appointment through API or UI
9. Show appointment list update
10. Call `/api/health` endpoint

## What to say during the demo
- The system implements the CAS core scheduling workflow described in the project brief.
- The stack follows Spring Boot, PostgreSQL, and React.
- CI validates backend tests and frontend build on every push/PR.
- Project work is tracked on the sprint board.
- Risks are reviewed and documented in the repository.

## Backup plan
- Keep Postman or curl examples ready.
- Keep Docker containers prebuilt.
- Keep screenshots of CI and board in case of network issues.

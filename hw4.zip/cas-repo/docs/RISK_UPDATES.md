# Risk Updates

| ID | Risk | Probability | Impact | Mitigation | Status |
|---|---|---:|---:|---|---|
| R1 | Schedule slip due to backend/frontend integration delays | Medium | High | Freeze MVP scope early, integrate by vertical slice | Open |
| R2 | Double booking caused by weak slot validation | Medium | High | Add unique slot checks and service-level validation | Mitigated in MVP |
| R3 | CI failures due to environment mismatch | Medium | Medium | Pin Java and Node versions in GitHub Actions | Mitigated |
| R4 | Database config errors in deployment | Medium | High | Use environment variables and documented setup | Open |
| R5 | Security gaps in authentication/authorization | High | High | Add Spring Security + JWT in next sprint | Open |
| R6 | Demo instability on live network | Medium | Medium | Keep local Docker fallback and recorded backup walkthrough | Open |

## Risk update summary
- Core delivery risk reduced by packaging a dockerized MVP.
- Technical risk remains around authentication because the current package is an MVP, not a production-complete release.
- Demo risk is manageable with a prepared fallback path.

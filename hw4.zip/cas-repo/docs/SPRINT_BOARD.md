# Sprint Board Setup

## Suggested GitHub Project columns
1. Backlog
2. Ready
3. In Progress
4. Review / Testing
5. Done

## Sprint 1 items
- Set up Spring Boot project
- Configure PostgreSQL and Flyway
- Create doctor and appointment entities
- Implement appointment API
- Seed doctor data
- Build React dashboard page
- Add Docker Compose
- Add GitHub Actions CI
- Prepare README and reports

## Suggested board link format
`https://github.com/users/<your-username>/projects/<project-number>`

## Demo board cards to highlight live
- MVP API working
- Frontend shows doctors and appointments
- CI pipeline green
- Risks reviewed and mitigations updated

import { useEffect, useState } from 'react'

export default function App() {
  const [doctors, setDoctors] = useState([])
  const [appointments, setAppointments] = useState([])

  useEffect(() => {
    fetch('/api/doctors').then(r => r.json()).then(setDoctors).catch(() => setDoctors([]))
    fetch('/api/appointments').then(r => r.json()).then(setAppointments).catch(() => setAppointments([]))
  }, [])

  return (
    <div className="page">
      <header>
        <h1>Clinical Appointment System</h1>
        <p>MVP dashboard for doctors and appointments</p>
      </header>

      <section>
        <h2>Active Doctors</h2>
        <ul>
          {doctors.map((doctor) => (
            <li key={doctor.id}>{doctor.fullName} — {doctor.specialty}</li>
          ))}
        </ul>
      </section>

      <section>
        <h2>Appointments</h2>
        <ul>
          {appointments.map((appt) => (
            <li key={appt.id}>
              {appt.patientName} with {appt.doctor?.fullName} at {appt.appointmentTime} [{appt.status}]
            </li>
          ))}
        </ul>
      </section>
    </div>
  )
}
